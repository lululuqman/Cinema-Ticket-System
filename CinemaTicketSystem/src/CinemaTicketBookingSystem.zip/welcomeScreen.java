import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class welcomeScreen{
	
	JFrame frame;
	JButton bookNow;
	
	public welcomeScreen(){
		frame = new JFrame();
		
		frame.setVisible(true);
		frame.setSize(1024, 768);
		frame.setTitle("Spark Cinema");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setLayout(new FlowLayout());
		
		bookNow = new JButton(new ImageIcon("C:/Users/Syafihakim/eclipse-workspace/CinemaTicketSystem/Images/BookNow.jpg"));
		bookNow.setBorder(BorderFactory.createEmptyBorder());
		bookNow.setCursor(new Cursor(Cursor.HAND_CURSOR));
		
		myPanel bg = new myPanel();
		bg.setLayout(new GridLayout(0,1,10,10));
		bg.setBorder(new EmptyBorder(350,300,350,300) );
		bg.add(bookNow);
		
		frame.add(bg);
		
		theHandler handler = new theHandler();
		bookNow.addActionListener(handler);
		
	}
	
	private class theHandler implements ActionListener{
		
		public void actionPerformed(ActionEvent e) {
			
			if(e.getSource()==bookNow) {
				new MovieScreen();
				frame.dispose();
			}
			
		}
		
	}
	
	private class myPanel extends JPanel{
		
		private static final long serialVersionUID = 1L;
		BufferedImage img;
		
		protected void paintComponent(Graphics g) {
			
			try {
	             img = ImageIO.read(new File("Images/welcome.jpg"));
	        } catch(IOException e) {
	            e.printStackTrace();
	        }
			
            super.paintComponent(g);
            g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
        }
		
	}
	
}
